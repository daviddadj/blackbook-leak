<?php
class Infusionsoft_FileService extends Infusionsoft_FileServiceBase{
}