<?php
class Infusionsoft_MtgLead extends Infusionsoft_Generated_MtgLead{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

