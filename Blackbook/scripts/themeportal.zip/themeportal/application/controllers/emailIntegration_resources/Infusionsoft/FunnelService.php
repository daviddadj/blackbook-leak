<?php
class Infusionsoft_FunnelService extends Infusionsoft_FunnelServiceBase{
}