<?php
class Infusionsoft_StageMove extends Infusionsoft_Generated_StageMove{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

