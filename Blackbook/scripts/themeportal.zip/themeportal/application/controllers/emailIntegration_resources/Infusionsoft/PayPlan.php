<?php
class Infusionsoft_PayPlan extends Infusionsoft_Generated_PayPlan{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

