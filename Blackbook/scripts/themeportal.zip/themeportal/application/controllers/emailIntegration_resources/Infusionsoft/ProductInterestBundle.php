<?php
class Infusionsoft_ProductInterestBundle extends Infusionsoft_Generated_ProductInterestBundle{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

