<form id=pay name=pay method="POST" action="https://merchant.wmtransfer.com/lmi/payment.asp">

<p>model payment via Merchant WebMoney Transfer</p>
<p>pay 1 WMZ...</p>

<p>
    <input type="hidden" name="LMI_PAYMENT_AMOUNT" value="1.0">
    <input type="hidden" name="LMI_PAYMENT_DESC" value="test payment">
    <input type="hidden" name="LMI_PAYMENT_NO" value="1">
    <input type="hidden" name="LMI_PAYEE_PURSE" value="Z134637156962">
    <input type="hidden" name="LMI_SIM_MODE" value="0">
    <input type="hidden" name="LMI_SUCCESS_URL" value="http://kamleshyadav.com/scripts/themeportal/home/s">
    <input type="hidden" name="LMI_SUCCESS_METHOD" value="1">
    <input type="hidden" name="LMI_FAIL_URL" value="http://kamleshyadav.com/scripts/themeportal/home/f">
    <input type="hidden" name="LMI_FAIL_METHOD" value="1">
</p>
<p>
    <input type="submit" value="submit">
</p>
</form>
LMI_PAYMENT_NO=1&LMI_SYS_INVS_NO=&LMI_SYS_TRANS_NO=&LMI_SYS_TRANS_DATE=&LMI_LANG=en-US
