<?php $ts_uid="";
if(isset($this->session->userdata['ts_uid'])){
	 $ts_uid=$this->session->userdata['ts_uid'];
}
 
 ?>
<!-- Breadcrumb wrapper Start -->
<div class="ts_breadcrumb_wrapper ts_toppadder50 ts_bottompadder50" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="600">
	<div class="ts_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ts_pagetitle">
					<h3><?php echo $productdetails[0]['prod_name'];?></h3>
				</div>
			</div>

		</div>
	</div>
</div>
<!-- Breadcrumb wrapper End -->
<!-- PostComments wrapper Start -->

<div class="ts_postcomments_wrapper ts_toppadder100 ts_bottompadder100">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<div class="ts_postcomments_section">
					 <div class="ts_authorbox">
						 <h3 class="ts_post_topic"><?php echo $this->ts_functions->getlanguage('commentstext','singleproductpage','solo');?> (<?php echo $comment_count; ?>)</h3> 
					</div>
					<?php //echo "<pre>";print_r($comments_list);?>
					<?php if(!empty($comments_list)) { ?>
					<ul class="ts_mainpost">
					<?php foreach($comments_list as $parent_comment): ?>
						<li>
							<div class="ts_postbox">
							<?php $parent_image_src= base_url().'webimage/dummy_testi.jpg';
							if($parent_comment['user_pic']!=""){
							$parent_image_src=base_url().'webimage/'.$parent_comment['user_pic'];
							}
							?>
								<img src="<?php echo $parent_image_src ; ?>" alt="" title="">
								<div class="ts_cmnt_details">
									<h4 class="ts_postbox_title"><a href=""><?php echo $parent_comment['user_uname'];  ?>  </a>
										
									</h4>
									<span class="ts_postbox_time"><a href=""><?php echo time_elapsed_string($parent_comment['comment_date']); ?></a></span>
									<p class="ts_postbox_text"><?php echo $parent_comment['comment_text'];  ?></p>
									<?php if($ts_uid!=""): ?>
									<div class="ts_postbox_reply">
										<ul>
											<li><a href="javascript:" onclick="repy_form(<?php echo $parent_comment['comment_id'] ?>,this)">replay <i class="fa fa-share" aria-hidden="true"></i></a></li>
										</ul>
									</div>
									<?php endif; ?>
								</div>
								<div class="ts_cmntrplybox hide" id="ts_cmntrplybox">
									
								</div>
								
							</div>
							<?php 
							$child_comments=$this->ts_functions->get_child_comments($parent_comment['comment_id']);
								if(!empty($child_comments)):
							?>
							
							<ul class="ts_mainpost_reply">
							<?php foreach($child_comments as $child_comment): ?>
								<li>
									<div class="ts_postbox">
									<?php $child_image_src= base_url().'webimage/dummy_testi.jpg';
							if($child_comment['user_pic']!=""){
							$child_image_src=base_url().'webimage/'.$child_comment['user_pic'];
							}
							?>
										<img src="<?php echo $child_image_src; ?>"  class="img-responsive" alt="" title="">
										<div class="ts_cmnt_details ts_author_cmnt">
											<h4 class="ts_postbox_title"><a href=""><?php echo $child_comment['user_uname'];  ?></a></h4>
											<span class="ts_postbox_time"><a href=""><?php echo time_elapsed_string($child_comment['comment_date']); ?></a></span>
											<p class="ts_postbox_text"><?php echo $child_comment['comment_text'];  ?></p>
											<?php if($ts_uid!=""): ?>
											<div class="ts_postbox_reply">
												<ul>
													<li><a href="javascript:" onclick="repy_form(<?php echo $parent_comment['comment_id'] ?>,this)">replay <i class="fa fa-share" aria-hidden="true"></i></a></li>
												</ul>
											</div>
											<?php endif; ?>
										</div>
										<div class="ts_cmntrplybox hide" id="ts_cmntrplybox">
									
								         </div>
									</div>
								</li>
							<?php endforeach; ?>	
							</ul>
							<?php endif; ?>
						</li>
						<?php endforeach;?>
						
						<div class="hide" id="reply_form_div">
						   <div class="form-group">
						   <input type="hidden" id="product_id" value="<?php echo $productdetails[0]['prod_id'];?>">
										<textarea class="form-control validate" rows="6" placeholder="Your Replay" id="msg"></textarea>
									</div>
									<a href="javascript:" onclick="" class="ts_btn" id="reply_to_main_a">post <i class="fa fa-paper-plane" aria-hidden="true"></i></a>
						   </div>
						
					</ul>
					<?php } 
					if(isset($this->session->userdata['ts_uid'])) {	
					    $vName = $this->ts_functions->getVendorName($this->session->userdata['ts_uid']);
					?>
					<div class="ts_newpost">
						<h3 class="ts_newtitle">Post a new comment</h3>
						<img src="<?php echo $basepath.'webimage/'.$this->ts_functions->getVendorPic($this->session->userdata['ts_uid']);?>" alt="<?php echo $vName;?>" title="<?php echo $vName;?>">
						<div class="ts_newpostbox">
							<!-- 
<div class="ts_widget_rating">
								<div class="ts_rating">
									<ul>
										<li><a class="rating_star livestars" alt="1" data-prod="0"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star livestars" alt="2" data-prod="0"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star livestars" alt="3" data-prod="0"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star livestars" alt="4" data-prod="0"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star livestars" alt="5" data-prod="0"><i class="fa fa-star" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
 -->
							<div class="form-group">
								<textarea class="form-control" rows="6" placeholder="Your Message" id="newcomment_0"></textarea>
							</div>
							<a onclick="send_comment_post(<?php echo $productdetails[0]['prod_id'];?>,0)" class="ts_btn">post <i class="fa fa-paper-plane" aria-hidden="true"></i></a>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ts_sidebar_responsive_none">
				<div class="ts_sidebar_wrapper">
					<aside class="widget widget_license">
						<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('licenseheading','singleproductpage','solo');?></h4>
						<div class="ts_widget_license_info">
							<div class="ts_widget_rating">
								<div class="ts_rating">
									<ul>
										<li><a class="rating_star" alt="1"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="2"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="3"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="4"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="5"><i class="fa fa-star" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
							<?php if( $productdetails[0]['prod_free'] == '0') {
                                if( $this->ts_functions->getsettings('portal','revenuemodel') != 'subscription' ) { ?>

                                    <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('addtocart','homepage','solo');?> </a>

                                    <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('buynowtab','homepage','solo');?> - <?php echo $this->ts_functions->getsettings('portalcurreny','symbol');?><?php echo $productdetails[0]['prod_price'];?> </a>

                                <?php } else { ?>
                                    <a href="<?php echo $basepath;?>shop/checkmembership/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('buynowtab','homepage','solo');?> </a>
							<?php   }
							    } else {
							        // Free
							    ?>
							        <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('freetext','commontext','solo');?></a>

							<?php } ?>


							<!-- <a href="javascript:;" class="ts_about_license">Read about the license</a> -->
						</div>
					</aside>
					<aside class="widget widget_meta_attributese">
							<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('productheading','singleproductpage','solo');?></h4>
							<?php
							    $vName = $this->ts_functions->getVendorName($productdetails[0]['prod_uid']);
							?>
							<div class="ts_widget_img">
								<img src="<?php echo $basepath.'webimage/'.$this->ts_functions->getVendorPic($productdetails[0]['prod_uid']);?>" alt="<?php echo $vName;?>" title="<?php echo $vName;?>">
							</div>
							<dl>
							    <dt><?php echo $this->ts_functions->getlanguage('vendornametext','singleproductpage','solo');?></dt>
								<dd> : <a href="<?php echo $basepath;?>vendor/<?php echo $vName;?>"><?php echo ucfirst($vName); ?></a> </dd>

								<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('createsubheading','singleproductpage','solo');?></dt>
								<dd> : <?php echo date_format(date_create ( $productdetails[0]['prod_date'] ) , 'M d, Y');?> </dd>

								<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('updateddatetext','singleproductpage','solo');?></dt>
								<dd> : <?php echo date_format(date_create ( $productdetails[0]['prod_update'] ) , 'M d, Y');?></dd>

								<!--<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('ratingssubheading','singleproductpage','solo');?></dt>
								<dd> : 8.9/10</dd> -->

								<div class="clearfix"></div>

								<?php if( $this->ts_functions->getsettings('portal','revenuemodel') != 'subscription' ) {
								    $purDetail = $this->DatabaseModel->access_database('ts_purchaserecord','select','',array('purrec_prodid'=>$productdetails[0]['prod_id']));
								?>
								<dt><?php echo $this->ts_functions->getlanguage('downloadssubheading','singleproductpage','solo');?></dt>
								<dd> : <?php echo count($purDetail);?></dd>
								<?php } ?>

								<div class="clearfix"></div>

							</dl>
						</aside>
				
				</div>
			</div>
		</div>
	</div>
</div>
<!-- PostComments wrapper End -->


<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 ts_sidebar_responsive">
								<div class="ts_sidebar_wrapper">
					<aside class="widget widget_license">
						<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('licenseheading','singleproductpage','solo');?></h4>
						<div class="ts_widget_license_info">
							<div class="ts_widget_rating">
								<div class="ts_rating">
									<ul>
										<li><a class="rating_star" alt="1"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="2"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="3"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="4"><i class="fa fa-star" aria-hidden="true"></i></a></li>
										<li><a class="rating_star" alt="5"><i class="fa fa-star" aria-hidden="true"></i></a></li>
									</ul>
								</div>
							</div>
							<?php if( $productdetails[0]['prod_free'] == '0') {
                                if( $this->ts_functions->getsettings('portal','revenuemodel') != 'subscription' ) { ?>

                                    <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('addtocart','homepage','solo');?> </a>

                                    <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('buynowtab','homepage','solo');?> - <?php echo $this->ts_functions->getsettings('portalcurreny','symbol');?><?php echo $productdetails[0]['prod_price'];?> </a>

                                <?php } else { ?>
                                    <a href="<?php echo $basepath;?>shop/checkmembership/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('buynowtab','homepage','solo');?> </a>
							<?php   }
							    } else {
							        // Free
							    ?>
							        <a href="<?php echo $basepath;?>shop/add_to_cart/products/<?php echo $productdetails[0]['prod_uniqid'];?>" class="ts_btn"> <?php echo $this->ts_functions->getlanguage('freetext','commontext','solo');?></a>

							<?php } ?>


							<!-- <a href="javascript:;" class="ts_about_license">Read about the license</a> -->
						</div>
					</aside>
					<aside class="widget widget_meta_attributese">
							<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('productheading','singleproductpage','solo');?></h4>
							<?php
							    $vName = $this->ts_functions->getVendorName($productdetails[0]['prod_uid']);
							?>
							<div class="ts_widget_img">
								<img src="<?php echo $basepath.'webimage/'.$this->ts_functions->getVendorPic($productdetails[0]['prod_uid']);?>" alt="<?php echo $vName;?>" title="<?php echo $vName;?>">
							</div>
							<dl>
							    <dt><?php echo $this->ts_functions->getlanguage('vendornametext','singleproductpage','solo');?></dt>
								<dd> : <a href="<?php echo $basepath;?>vendor/<?php echo $vName;?>"><?php echo ucfirst($vName); ?></a> </dd>

								<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('createsubheading','singleproductpage','solo');?></dt>
								<dd> : <?php echo date_format(date_create ( $productdetails[0]['prod_date'] ) , 'M d, Y');?> </dd>

								<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('updateddatetext','singleproductpage','solo');?></dt>
								<dd> : <?php echo date_format(date_create ( $productdetails[0]['prod_update'] ) , 'M d, Y');?></dd>

								<!--<div class="clearfix"></div>

								<dt><?php echo $this->ts_functions->getlanguage('ratingssubheading','singleproductpage','solo');?></dt>
								<dd> : 8.9/10</dd> -->

								<div class="clearfix"></div>

								<?php if( $this->ts_functions->getsettings('portal','revenuemodel') != 'subscription' ) {
								    $purDetail = $this->DatabaseModel->access_database('ts_purchaserecord','select','',array('purrec_prodid'=>$productdetails[0]['prod_id']));
								?>
								<dt><?php echo $this->ts_functions->getlanguage('downloadssubheading','singleproductpage','solo');?></dt>
								<dd> : <?php echo count($purDetail);?></dd>
								<?php } ?>

								<div class="clearfix"></div>

							</dl>
						</aside>
				
				</div>
							</div>
<input type="hidden" value="<?php echo $this->ts_functions->getlanguage('emptyerror','commontext','solo');?>" id="emptyerror">
