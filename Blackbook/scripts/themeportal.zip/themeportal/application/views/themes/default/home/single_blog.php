<!-- Breadcrumb wrappe Start -->
<div class="ts_breadcrumb_wrapper ts_toppadder50 ts_bottompadder50" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="600">
	<div class="ts_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ts_pagetitle">
					<h3><?php echo $blog_detail[0]['blog_title']; ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Breadcrumb wrappe End -->
<!--Blog content start-->
<div class="ts_blog_wrapper ts_toppadder90 ts_bottompadder90">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-9">
				<div class="ts_blog_all_item">
					<div class="ts_blog_item ts_bottompadder50">
					<?php if(!empty($blog_detail[0]['blog_image'])){
						$blog_img_src=base_url().'repo/images/'.$blog_detail[0]['blog_image'];
						?>
						<div class="ts_blog_image">
							<img src="<?php echo $blog_img_src; ?>" alt="blog image" />
						</div>
					<?php } ?>	
						<div class="ts_blog_info">
							<h2><?php echo $blog_detail[0]['blog_title']; ?></h2>
							<ul>
								<li><a href="javascript:"><i class="fa fa-user"></i>Admin</a></li>
								<li><a href="javascript:"><i class="fa fa-clock-o"></i> <?php echo date("M d,Y", strtotime($blog_detail[0]['blog_date'])); ?></a></li>
								<li><a href="javascript:"><i class="fa fa-comment-o"></i> <?php echo $comment_count; ?></a></li>
							</ul>
							<p><?php echo $blog_detail[0]['blog_content']; ?></p>
						</div>
					</div>
					<!--Comments section start-->
					<div class="ts_blog_comment_wrapper">
						
						<?php if(!empty($comments)): ?>
						<h4><?php echo $this->ts_functions->getlanguage('allcomment','commontext','solo');?></h4>
						<?php foreach($comments as $comment): ?>
						<div class="ts_blog_comment ts_toppadder30">
							<div class="ts_comment_image"> <img src="<?php echo  base_url().'webimage/dummy_testi.jpg'; ?>" alt="" /> </div>
							<div class="ts_comment_text">
								<h5><?php echo $comment['comment_uname']; ?><span><?php echo date("M d,Y", strtotime($comment['comment_date'])); ?><?php if($comment['comment_status']==1){?><a class="comment_reply" onclick="repy_form(<?php echo $comment['comment_id'] ?>,this,'blog')">Reply</a><?php } ?></span></h5>
								<p><?php if($comment['comment_status']==1){?>
															<p><?php echo $comment['comment_text'];  ?></p>
															<?php } else{ ?>
															<p><?php echo $this->ts_functions->getlanguage('awaitingmoderation','commontext','solo');?></p>
															<?php } ?></p>
							</div>
							<div class="ts_cmntrplybox hide" id="ts_cmntrplybox">
							
							</div>
							
						</div>
						<?php $replies=$this->DatabaseModel->access_database('ts_comments','select', '' , array('comment_parent'=>$comment['comment_id'],'comment_type'=>'blog')); ?>
						<?php if(!empty($replies)){ ?>
						<?php foreach($replies as $reply){ ?>
						<div class="ts_blog_sub_comment ts_toppadder30">
							<div class="ts_comment_image"> <img src="<?php echo  base_url().'webimage/dummy_testi.jpg'; ?>" alt="" /> </div>
							<div class="ts_comment_text">
								<h5><?php echo $reply['comment_uname']; ?><span><?php echo date("M d,Y", strtotime($reply['comment_date'])); ?></span></h5>
								<p><?php if($reply['comment_status']==1){?>
									<p><?php echo $reply['comment_text'];  ?></p>
									<?php } else{ ?>
									<p><?php echo $this->ts_functions->getlanguage('awaitingmoderation','commontext','solo');?></p>
									<?php } ?></p>
							</div>
						</div>
						<?php } } ?>
							
						<?php endforeach; ?>
						<?php endif;?>
						
						
						
					</div>
					<!--Comments section end-->
					<!--Comments Form start-->
					<?php
			if($this->session->userdata('ts_login')){
				$cmt_name =$this->session->userdata('ts_uname');
				$cmt_uid= $this->session->userdata('ts_uid');
				$cmtuserdata=$this->DatabaseModel->access_database('ts_user','select','',array('user_id'=>$cmt_uid));
				$cmt_email=$cmtuserdata[0]['user_email'];
			}
			?>		
					<div class="ts_blog_message_wrapper">
						<h4> <?php echo $this->ts_functions->getlanguage('commentstext','singleproductpage','solo');?></h4>
						<div class="ts_blog_messages ts_toppadder30">
							<div class="row">
								<form>
									<div class="form-group">
										<div class="col-lg-6 <?php if(isset($cmt_name)) echo 'hide'; ?>">
											<input type="text" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('yourname','commontext','solo');?>" name="cmt_name_0" id="cmt_name_0" value="<?php if(isset($cmt_name)) echo $cmt_name; ?>" />
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-6 <?php if(isset($cmt_email)) echo 'hide'; ?>">
											<input type="email" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('yoursemail','commontext','solo');?>" id="cmt_email_0" name="cmt_email_0" value="<?php if(isset($cmt_email)) echo $cmt_email; ?>"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-12">
											<textarea class="form-control" rows="5" placeholder="<?php echo $this->ts_functions->getlanguage('yourmsg','commontext','solo');?>" name="cmt_comment_0" id="cmt_comment_0"></textarea>
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-12 text-right">
											<a onclick="send_comment_post(<?php echo $blog_detail[0]['blog_id'];?>,0,'','blog')" class="btn ts_btn ts_orange"><?php echo $this->ts_functions->getlanguage('commentstext','singleproductpage','solo');?></a>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				<!--Comments Form end-->
				</div>
			</div>
<!--Sidebar Start-->
			<div class="col-lg-3 col-md-3 col-sm-3">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('searchplaceholder','homepage','solo');?>" id="searchInput">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button" id="searchInputBtn"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					
					
					<aside class="widget widget_categories">
						<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('categories','commontext','solo');?></h4>
						<?php if(!empty($blog_categories)){ ?>
						<ul>
						<?php foreach($blog_categories as $single_category){ ?>
							<li><a href="<?php echo $basepath.'blogs/?category='.strtolower($single_category['blog_category_slug']);?>"><?php echo strtoupper($single_category['blog_category_name']);  ?></a></li>
							
						<?php  } ?>	
						</ul>
						<?php } ?>
					</aside>
					
					
					
				</div>
			</div>
<!--Sidebar End-->
		</div>
	</div>  
</div>
<!--Blog content end-->
<input type="hidden" value="<?php echo $this->ts_functions->getlanguage('emptyerror','commontext','solo');?>" id="emptyerror">
<input type="hidden" value="<?php echo $this->ts_functions->getlanguage('email','message','solo');?>" id="emailerr_text">
<div class="hide" id="reply_form_div">
<input type="hidden" id="product_id" value="<?php echo $blog_detail[0]['blog_id'];?>">
        <div class="ts_blog_messages ts_toppadder30">
							<div class="row">
								<form>
									<div class="form-group">
										<div class="col-lg-6 <?php if(isset($cmt_name)) echo 'hide'; ?>">
											<input type="text" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('yourname','commontext','solo');?>" name="cmt_name" id="cmt_name" value="<?php if(isset($cmt_name)) echo $cmt_name; ?>" />
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-6 <?php if(isset($cmt_email)) echo 'hide'; ?>">
											<input type="email" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('yoursemail','commontext','solo');?>" id="cmt_email" name="cmt_email" value="<?php if(isset($cmt_email)) echo $cmt_email; ?>"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-12">
											<textarea class="form-control" rows="5" placeholder="<?php echo $this->ts_functions->getlanguage('yourmsg','commontext','solo');?>" name="cmt_comment" id="cmt_comment"></textarea>
										</div>
									</div>
									<div class="form-group">
										<div class="col-lg-12 text-right">
											<a id="reply_to_main_a" onclick="send_comment_post(<?php echo $blog_detail[0]['blog_id'];?>,0,'','blog')" class="btn ts_btn ts_orange"><?php echo $this->ts_functions->getlanguage('commentstext','singleproductpage','solo');?></a>
										</div>
									</div>
								</form>
							</div>
	</div>
</div>