<!-- Breadcrumb wrappe Start -->
<div class="ts_breadcrumb_wrapper ts_toppadder50 ts_bottompadder50" data-stellar-background-ratio="0.5" data-stellar-vertical-offset="600">
	<div class="ts_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="ts_pagetitle">
					<h3><?php if(isset($_GET['category'])){ echo $_GET['category'];  }else { echo $this->ts_functions->getlanguage('blogtext','menus','solo');} ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Breadcrumb wrappe End -->
<!--Blog content start-->
<div class="ts_blog_wrapper ts_toppadder90 ts_bottompadder90">
	<div class="container">
		<div class="row">
		
			<div class="col-lg-9 col-md-9 col-sm-9">
			<?php if(!empty ($blog_list)){ ?>
				<div class="ts_blog_all_item">
				<?php foreach($blog_list as $blog) { ?>
					<div class="ts_blog_item ts_bottompadder50">
					<?php if(!empty($blog['blog_image'])){
						$blog_img_src=base_url().'repo/images/'.$blog['blog_image'];
						?>
						<div class="ts_blog_image">
							<a href="<?php echo base_url();?>blogs/blog_post/<?php echo strtolower($blog['blog_slug']); ?>"><img src="<?php echo $blog_img_src; ?>" alt="blog image" /></a>
						</div>
					<?php  } ?>		
						<div class="ts_blog_info">
							<h2><a href="<?php echo base_url();?>blogs/blog_post/<?php echo strtolower($blog['blog_slug']); ?>"><?php echo $blog['blog_title']; ?></a></h2>
							<ul>
								<li><a href="javascript:"><i class="fa fa-user"></i> Admin</a></li>
								
								<li><a href="javascript:"><i class="fa fa-clock-o"></i> <?php echo date("M d,Y", strtotime($blog['blog_date'])); ?></a></li>
								
							</ul>
							
							<p class="ts_bottompadder10"><?php echo substr($blog['blog_content'],0,240); ?></p>
							<a href="<?php echo base_url();?>blogs/blog_post/<?php echo strtolower($blog['blog_slug']); ?>" class="btn ts_btn ts_orange"><?php echo $this->ts_functions->getlanguage('viewmoretext','commontext','solo');?></a>
						</div>
					</div>
			<?php } ?>	
					
					
					<div class="col-lg-12">
						<div class="ts_pagination">
							<div class="row">
								<nav>
									<?php echo (isset($pagination_data))?$pagination_data:''; ?>
								</nav>
							</div>
						</div>
					</div>	
				</div>
			<?php } else {?>
			<img class="img-responsive" src="<?php echo $basepath;?>themes/default/images/web/notfoundimg.png" alt="Oops , there is nothing to show" title="Oops , there is nothing to show">
			<?php } ?>			
			</div>
		
			<!--Sidebar Start-->
			<div class="col-lg-3 col-md-3 col-sm-3">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="<?php echo $this->ts_functions->getlanguage('searchplaceholder','homepage','solo');?>" id="searchInput">
							<span class="input-group-btn">
								<button class="btn btn-default" id="searchInputBtn" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					
					<aside class="widget widget_categories">
						<h4 class="widget-title"><?php echo $this->ts_functions->getlanguage('categories','commontext','solo');?></h4>
						<?php if(!empty($blog_categories)){ ?>
						<ul>
						<?php foreach($blog_categories as $single_category){ ?>
							<li><a href="<?php echo $basepath.'blogs/?category='.strtolower($single_category['blog_category_slug']);?>"><?php echo strtoupper($single_category['blog_category_name']);  ?></a></li>
							
						<?php  } ?>	
						</ul>
						<?php } ?>
					</aside>
					
					
					
				</div>
			</div>
			<!--Sidebar End-->
		</div>
	</div>  
</div>
<!--Blog content end-->
