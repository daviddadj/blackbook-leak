<div class="main_body">
      	<!-- user content section -->
		<div class="theme_wrapper">
			<div class="container-fluid">
				<div class="theme_section">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<div class="th_manage_user">
								<h3 class="th_title">Comments</h3>

								<div class="table-responsive">
								<table class="commonTable table table-striped table-bordered manage_user" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th>User Name</th>
											<th>User Email</th>
											<th>Comment</th>
											<th>Parrent Comment</th>
											<th>Status</th>
											
										</tr>
									<thead>
									<tfoot>
										<tr>
											<th>#</th>
											<th>User Name</th>
											<th>User Email</th>
											<th>Comment</th>
											<th>Parrent Comment</th>
											<th>Status</th>
											
										</tr>
									<tfoot>
									<tbody>
							<?php if(!empty($comments_list)) {
							    $count = 0;
							    foreach($comments_list as $comment) {
							    
							    $count++;
						    ?>
									<tr>
										<td><?php echo $count;?></td>
										<td><?php echo $comment['user_uname'];?></td>
										<td><?php echo $comment['user_email'];?></td>
										<td><?php echo $comment['comment_text'];?></td>
										<?php
										$parent_comment_text="";
								if($comment['comment_parent']!=0){
									$comment_parent_id=$comment['comment_parent'];
									$parent_comment_detail = $this->DatabaseModel->access_database('ts_comments','select','',array('comment_id'=>$comment_parent_id));
									$parent_comment_text=$parent_comment_detail[0]['comment_text'];
									
								}
										?>
										<td><?php echo $parent_comment_text;?></td>
										<td>
										<select onchange="updatethevalue(this,'comment');" id="<?php echo $comment['comment_id'].'_status';?>">
										    <option value="1" <?php echo ($comment['comment_status'] == '1' ? 'selected' : '' ); ?>>Active</option>
										    <option value="0" <?php echo ($comment['comment_status'] == '0' ? 'selected' : '' ); ?>>In Active</option>
										</select>
										</td>
										

										

									</tr>
							<?php } } ?>
							<?php if(!empty($blog_comment_list)) {
							    $count = 0;
							    foreach($blog_comment_list as $comment) {
							    
							    $count++;
						    ?>
									<tr>
										<td><?php echo $count;?></td>
										<td><?php echo $comment['comment_uname'];?></td>
										<td><?php echo $comment['comment_email'];?></td>
										<td><?php echo $comment['comment_text'];?></td>
										<?php
										$parent_comment_text="";
								if($comment['comment_parent']!=0){
									$comment_parent_id=$comment['comment_parent'];
									$parent_comment_detail = $this->DatabaseModel->access_database('ts_comments','select','',array('comment_id'=>$comment_parent_id));
									$parent_comment_text=$parent_comment_detail[0]['comment_text'];
									
								}
										?>
										<td><?php echo $parent_comment_text;?></td>
										<td>
										<select onchange="updatethevalue(this,'comment');" id="<?php echo $comment['comment_id'].'_status';?>">
										    <option value="1" <?php echo ($comment['comment_status'] == '1' ? 'selected' : '' ); ?>>Active</option>
										    <option value="0" <?php echo ($comment['comment_status'] == '0' ? 'selected' : '' ); ?>>In Active</option>
										</select>
										</td>
										

										

									</tr>
							<?php } } ?>
									<tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- user content section -->
	</div>
