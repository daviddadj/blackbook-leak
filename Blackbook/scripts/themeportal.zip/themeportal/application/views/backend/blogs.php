<div class="main_body">
    <!-- add user modal start -->
       <!-- user content section -->
		<div class="theme_wrapper">
			<div class="container-fluid">

				<div class="theme_section">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<div class="th_manage_user">
								<h3 class="th_title">manage blogs</h3>
								<div class="table-responsive">
								<table class="commonTable table table-striped table-bordered manage_user" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th> Title</th>
											<th>Category</th>	
											<th>Created Date</th>	
											<th>Status</th>
											<th class="action">Action</th>
										</tr>
									<thead>
									<tfoot>
										<tr>
											<th>#</th>
											<th> Title</th>
											<th>Category</th>	
											<th>Created Date</th>	
											<th>Status</th>
											<th class="action">Action</th>
										</tr>
									<tfoot>
									<tbody>
							<?php if(!empty($blog_list)) {
							    $count = 0;
							    foreach($blog_list as $soloblog) {
							    $blog_id=$soloblog['blog_id'];
							    $count++;
						    ?>
									<tr>
										<td><?php echo $count;?></td>
										<td><?php echo $soloblog['blog_title'];?></td>
										
										<?php 
										$cat_detail= $this->DatabaseModel->access_database('ts_blog_category','select','',array('blog_category_id'=>$soloblog['blog_category']));
										$cat_name=$cat_detail[0]['blog_category_name'];
										?>
										<td><?php echo $cat_name;?></td>
										<td><?php echo $soloblog['blog_date'];?></td>
							
										<td>

										<select onchange="updatethevalue(this,'blog');" id="<?php echo $blog_id.'_status';?>">
										    <option value="1" <?php echo ($soloblog['blog_status'] == '1' ? 'selected' : '' ); ?>>Publish</option>
										    <option value="0" <?php echo ($soloblog['blog_status'] == '0' ? 'selected' : '' ); ?>>UnPublish</option>
										    
										</select>
										</td>
										<td>
                                        <a href="<?php echo $basepath?>blogs/blog_post/<?php echo strtolower($soloblog['blog_slug']);?>"  class="delete" title="View" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i></a>
										<a href="<?php echo $basepath?>backend/update_blog/<?php echo $blog_id;?>" class="edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<a href=<?php echo $basepath?>backend/view_comments/<?php echo $blog_id;?> class="comment" ><i class="fa fa-comment" aria-hidden="true"></i></a>
										</td>
									</tr>
							<?php } } ?>
									<tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- user content section -->
	</div>
