<div class="main_body">
      	<!-- user content section -->
		<div class="theme_wrapper">
			<div class="container-fluid">
				<div class="theme_section">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<div class="th_manage_user">
								<h3 class="th_title">Ratings</h3>

								<div class="table-responsive">
								<table class="commonTable table table-striped table-bordered manage_user" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>#</th>
											<th>User Name</th>
											<th>Rating</th>
											
											
										</tr>
									<thead>
									<tfoot>
										<tr>
											<th>#</th>
											<th>User Name</th>
											<th>Rating</th>
											
											
										</tr>
									<tfoot>
									<tbody>
							<?php if(!empty($rating_list)) {
							    $count = 0;
							    foreach($rating_list as $rating) {
							    
							    $count++;
						    ?>
									<tr>
										<td><?php echo $count;?></td>
										<td><?php echo $rating['user_uname'];?></td>
										<td>
										<?php $rating['rating_stars'];
										for($count=1;$count<=$rating['rating_stars'];$count++){
										echo '<i class="fa fa-star" aria-hidden="true"></i>';
										}
										?></td>
										
										</td>
										

										

									</tr>
							<?php } } ?>
									<tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- user content section -->
	</div>
