<!---- Editor dependent JS on TOP -------->
<script type="text/javascript" src="<?php echo $basepath;?>adminassets/js/jquery-1.12.3.js"></script>
<?php $h_arr = explode('http://', $basepath);
	if( count($h_arr) == 2 ) {
?>
<script src="http://cdn.ckeditor.com/4.5.9/standard/ckeditor.js"></script>
<?php } else { ?>
<script src="https://cdn.ckeditor.com/4.5.9/standard/ckeditor.js"></script>
<?php } ?>
<!---- Editor dependent JS on TOP -------->
<div class="main_body">
		<!-- user content section -->
		<div class="theme_wrapper">
			<div class="container-fluid">
				<div class="theme_section">
					<div class="row">
						<div class="col-lg-12 col-md-12">
<div class="theme_page">
<?php $topText = (isset($solo_blog) ? 'Update Blog ' : 'Add Blog' );?>
    <div class="theme_panel_section">
        <h4 class="th_title"><?php echo $topText;?></h4>
          <div class="th_content_section">
                
					 <div class="alert alert-info th_setting_text">
						<p><i style="color:red;" class="fa fa-bell" aria-hidden="true"></i> Fill in those details which you want, remember fields with (<b style="color:red;">*</b>) are mandatory. <br/> The empty fields will not show up to the user.</p>
					</div>
					<form id="add_blog_content" autocomplete="off" method="post" action="<?php echo base_url();?>backend/add_blog" enctype="multipart/form-data">
                    <div class="form-group">
                       <label>Title<b style="color:red;">*</b></label>
                        <input type="text" class="form-control blogfields" name="b_title" id="b_title" value="<?php if(isset($solo_blog)) { echo $solo_blog[0]['blog_title']; } ?>">
                    </div>
                    <div class="form-group">
                       <label>Category <b style="color:red;">*</b></label>
                             <select class="form-control blogfields" id="b_category" name="b_category">
                             <option value="0">Choose one</option>
                             <?php
                             foreach($categoryList as $soloCate) {
                                if( isset($solo_blog) ) {
                                    $selected = ($solo_blog[0]['blog_category'] == $soloCate['blog_category_id']) ? 'selected' : '' ;
                                }
                                else {
                                    $selected = '';
                                }
                                echo '<option value="'.$soloCate['blog_category_id'].'" '.$selected.'>'.$soloCate['blog_category_name'].'</option>';
                              } ?>
                            </select>
                    </div>
					<div class="form-group">
                            <label>Content <b style="color:red;">*</b></label>
							<textarea rows="8" class="form-control" id="b_content" name="b_content"><?php if(isset($solo_blog)) { echo $solo_blog[0]['blog_content']; } ?></textarea>
					</div>
					<div class="form-group">
                       <label>Tags</label>
                        <input type="text" class="form-control" id="b_tags" name="b_tags" value="<?php if(isset($solo_blog)) { echo $solo_blog[0]['blog_tags']; } ?>">
                    </div>
					<div class="form-group">
                       <label>Feature Image</label>
                        <input type="file" class="form-control " id="b_image" name="b_image" >
                    </div>						
                    <div class="col-lg-12 col-md-12">
                        <div class="th_btn_wrapper">
                    <?php $btnText = (isset($solo_blog) ? 'UPDATE' : 'ADD' );?>
                            <button type="submit" class="btn theme_btn" onclick="return addblogbutton(this)"><?php echo $btnText; ?></button>
                        </div>
                    </div>
					<input type="hidden" id="blog_id" name="b_id" value="<?php echo (!empty($solo_blog) ? $solo_blog[0]['blog_id'] : '0');?>">
					</form>
                    
           </div>
    </div>
</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- user content section -->
	</div>
<script>

    var blog_editor=  CKEDITOR.replace('b_content', {
      height: 300,
      allowedContent:true,
      uiColor: '#6f5499'
      } );

</script>